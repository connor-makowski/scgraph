from .core import Graph, GeoGraph

# Ignore data module in docs
__pdoc__ = {"geographs": False}
