from .core import Graph

# Ignore data module in docs
__pdoc__ = {"data": False}
