# This file just imports the necessary modules to allow for backwards compatibility
from scgraph.graph import Graph
from scgraph.geograph import (
    GeoGraph,
    load_geojson_as_geograph,
    get_multi_path_geojson,
)
