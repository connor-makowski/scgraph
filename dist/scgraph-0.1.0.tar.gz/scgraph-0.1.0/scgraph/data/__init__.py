# from .marnet import marnet_data
from .example import example_data
from .marnet import marnet_data
