from scgraph.utils import (
    haversine,
    distance_converter,
    get_line_path,
    cheap_ruler,
    print_console,
    get_lat_lon_bound_between_pts,
    get_default_cache_path,
)
from scgraph.helpers.geojson import parse_geojson
from geokdtree import GeoKDTree
import json, requests, shutil
from copy import deepcopy
from pathlib import Path
from typing import Literal
from scgraph import Graph


class GeoGraphIO:
    # Save Methods

    def save_as_geojson(
        self,
        filename: str,
        compact: bool = False,
        save_intermediate_nodes: bool = True,
    ) -> None:
        """
        Function:

        - Save the current geograph object as a geojson file specifed by `filename`
        - This is useful for understanding the underlying geograph and for debugging purposes
        - Returns None

        Required Arguments:

        - `filename`
            - Type: str
            - What: The filename to save the geojson file as

        Optional Arguments:

        - `compact`
            - Type: bool
            - What:
                - If True, saves the geojson as a compact multiline string without distances or other properties
                - If False, saves the geojson as a feature collection with each line as a separate feature
                    - Note: If False, the resulting file can be loaded with the legacy load_geojson_as_geograph function
            - Default: False

        """
        graph = self.graph_object.graph
        if compact:
            multiline = []
            for origin_idx, destinations in enumerate(graph):
                for destination_idx, distance in destinations.items():
                    new_subline = [
                        [self.nodes[origin_idx][1], self.nodes[origin_idx][0]]
                    ]
                    if (
                        self.intermediate_nodes is not None
                        and save_intermediate_nodes
                    ):
                        im_pts = self.__get_intermediate_nodes__(
                            origin_idx=origin_idx,
                            destination_idx=destination_idx,
                            sequence="lon_lat",
                        )
                        if im_pts:
                            new_subline.extend(im_pts)
                    new_subline.append(
                        [
                            self.nodes[destination_idx][1],
                            self.nodes[destination_idx][0],
                        ]
                    )

                    multiline.append(new_subline)
            out_dict = {
                "type": "GeometryCollection",
                "geometries": [
                    {
                        "type": "MultiLineString",
                        "coordinates": multiline,
                    }
                ],
            }

        else:
            features = []
            for origin_idx, destinations in enumerate(graph):
                for destination_idx, distance in destinations.items():
                    origin = self.nodes[origin_idx]
                    destination = self.nodes[destination_idx]
                    new_subline = [[origin[1], origin[0]]]
                    if (
                        self.intermediate_nodes is not None
                        and save_intermediate_nodes
                    ):
                        im_pts = self.__get_intermediate_nodes__(
                            origin_idx=origin_idx,
                            destination_idx=destination_idx,
                            sequence="lon_lat",
                        )
                        if im_pts:
                            new_subline.extend(im_pts)
                    new_subline.append([destination[1], destination[0]])
                    features.append(
                        {
                            "type": "Feature",
                            "properties": {
                                "origin_idx": origin_idx,
                                "destination_idx": destination_idx,
                                "distance": distance,
                            },
                            "geometry": {
                                "type": "LineString",
                                "coordinates": new_subline,
                            },
                        }
                    )
            out_dict = {"type": "FeatureCollection", "features": features}
        with open(filename, "w") as f:
            json.dump(out_dict, f)

    def save_as_graphjson(
        self, filename: str, save_intermediate_nodes: bool = True
    ) -> None:
        """
        Function:

        - Save the current geograph as a JSON file that can be used to recreate the geograph later
        - This is particularly useful for larger geographs that you want to save and load later without having to recreate them from scratch
        - Only the graph and nodes are saved, not the methods or any other attributes of the GeoGraph class

        Required Arguments:

        - `filename`
            - Type: str
            - What: The filename to save the JSON file as
            - EG: 'custom.graphjson'
                - Stored as: 'custom.graphjson'
                    - In your current directory
            - Note: The filename must end with .graphjson

        Optional Arguments:

        - `save_intermediate_nodes`
            - Type: bool
            - What: Whether to include the intermediate nodes in the saved JSON file (if they exist)
            - Default: True
        """
        if not filename.endswith(".graphjson"):
            raise ValueError("Filename must end with .graphjson")
        extra_kwargs = {}
        if self.intermediate_nodes is not None and save_intermediate_nodes:
            extra_kwargs["intermediate_nodes"] = self.intermediate_nodes
        with open(filename, "w") as f:
            json.dump(
                {
                    "type": "GeoGraph",
                    "graph": self.graph_object.graph,
                    "nodes": self.nodes,
                    "default_off_graph_circuity": self.default_off_graph_circuity,
                    "default_node_addition_circuity": self.default_node_addition_circuity,
                    "geograph_units": self.geograph_units,
                    **extra_kwargs,
                },
                f,
            )

    # Load Methods
    @staticmethod
    def load_from_geojson(
        filename: str,
        precision: int = 5,
        pct_to_keep: int | float = 100,
        min_points=3,
        load_intermediate_nodes: bool = True,
        silent: bool = False,
        reduce_iterations: int = 0,
        lazy: bool = False,
    ):
        """
        Function:

        - Load a GeoGraph from an arbitrary geojson file (GeometryCollection or FeatureCollection)
        - This function
            - Merges all LineStrings and MultiLineStrings into a single MultiLineString
            - Simplifies the MultiLineString to reduce the number of points using a percentage based Visvalengam simplification algorithm
            - Rounds the coordinates to the specified precision
            - Merges lines that start and end at the same location after rounding
            - Converts the MultiLineString into a GeoGraph object
        - Note:
            - All arcs read in will be undirected


        Required Arguments:

        - `filename`
            - Type: str
            - What: The filename of the geojson file to load
            - EG: 'custom.geojson'
                - Stored as: 'custom.geojson'
                    - In your current directory

        Optional Arguments:

        - `precision`
            - Type: int
            - What: Decimal places to round coordinates when loading and simplifying the lines
            - Default: 4
        - `pct_to_keep`
            - Type: int|float
            - What: Percentage of the interior line points to keep (note the ends are always kept)
            - Default: 100
        - `min_points`
            - Type: int
            - What: Minimum number of points to keep in the simplified line (The ends are always kept but should be included in this count)
            - Default: 3
        - `load_intermediate_nodes`
            - Type: bool
            - What: Whether to load the intermediate nodes for each edge (if they exist) into the GeoGraph object
            - Default: True
            - Note: Not implemented yet.
        - `silent`
            - Type: bool
            - What: Whether to suppress progress output to the console when loading the geojson
            - Default: False
        - `reduce_iterations`
            - Type: int
            - What: Number of reduction iterations to perform upon loading. If 0, no reduction is done. If -1, reduces iteratively until convergence.
            - Default: 0
        - `lazy`
            - Type: bool
            - What: Whether to delay loading the geograph until its first use
            - Default: False
        """
        if lazy:
            return LazyGeoGraph(
                lambda: GeoGraph.load_from_geojson(
                    filename=filename,
                    precision=precision,
                    pct_to_keep=pct_to_keep,
                    min_points=min_points,
                    load_intermediate_nodes=load_intermediate_nodes,
                    silent=silent,
                    reduce_iterations=reduce_iterations,
                    lazy=False,
                )
            )
        data = parse_geojson(
            filename_in=filename,
            precision=precision,
            pct_to_keep=pct_to_keep,
            min_points=min_points,
            # load_intermediate_nodes=load_intermediate_nodes,
            silent=silent,
        )
        geograph = GeoGraph(
            graph=data["graph"],
            nodes=data["nodes"],
        )
        geograph.graph_object.reduce(reduce_iterations)
        return geograph

    @staticmethod
    def load_from_graphjson(
        filename: str,
        reduce_iterations: int = 0,
        lazy: bool = False,
    ) -> "GeoGraph":
        """
        Function:

        - Load a GeoGraph from a JSON file that was saved using the `save_as_graphjson` method

        Required Arguments:

        - `filename`
            - Type: str
            - What: The filename of the JSON file to load
            - EG: 'custom.json'
                - Stored as: 'custom.json'
                    - In your current directory

        Optional Arguments:

        - `reduce_iterations`
            - Type: int
            - What: Number of reduction iterations to perform upon loading. If 0, no reduction is done. If -1, reduces iteratively until convergence.
            - Default: 0
        - `lazy`
            - Type: bool
            - What: Whether to delay loading the geograph until its first use
            - Default: False

        Returns:

        - A GeoGraph object with the graph and nodes loaded from the JSON file
        """
        if lazy:
            return LazyGeoGraph(
                lambda: GeoGraph.load_from_graphjson(
                    filename=filename,
                    reduce_iterations=reduce_iterations,
                    lazy=False,
                )
            )
        if not filename.endswith(".graphjson"):
            raise ValueError("Filename must end with .graphjson")
        with open(filename, "r") as f:
            data = json.load(f)
        if data.get("type", None) != "GeoGraph":
            raise ValueError(
                "JSON file is not a valid GeoGraph. Ensure it was saved using the save_as_graphjson method."
            )
        data.pop("type")
        # Clean the graph data such that all keys are ints (JSON only allows string keys, but we want int keys for the graph)
        data["graph"] = [
            {int(k): v for k, v in item.items()} for item in data["graph"]
        ]
        geograph = GeoGraph(**data)
        geograph.graph_object.reduce(reduce_iterations)
        return geograph

    @staticmethod
    def __fetch_geograph_to_cache__(
        name: str, cached_file: Path, geograph_url: str
    ) -> None:
        """
        Function:

        - Download a built-in GeoGraph file from GitHub into the cache directory.

        Required Arguments:

        - `name`
            - Type: str
            - What: The name of the built-in geograph to fetch
        - `cached_file`
            - Type: Path
            - What: The destination path in the cache to write the file to
        """
        url = f"{geograph_url}/{name}.graphjson"
        response = requests.get(url)
        if response.status_code == 404:
            raise FileNotFoundError(
                f"Geograph '{name}' not found at '{url}'. "
                f"Check that the name is correct and the file exists in the scgraph GitHub repository."
            )
        if not response.ok:
            raise ConnectionError(
                f"Failed to download geograph '{name}' from '{url}'. "
                f"HTTP status: {response.status_code}."
            )
        cached_file.write_bytes(response.content)

    @staticmethod
    def load_geograph(
        name: str,
        cache_dir: str | None = None,
        geograph_url: str = "https://raw.githubusercontent.com/connor-makowski/scgraph/main/geographs",
        reduce_iterations: int = 0,
        lazy: bool = False,
    ) -> "GeoGraph":
        """
        Function:

        - Load a built-in GeoGraph by name, using a local cache.
        - On first call for a given name, downloads the .graphjson file from GitHub into the cache directory.
        - On subsequent calls, loads directly from cache without any network requests.

        Required Arguments:

        - `name`
            - Type: str
            - What: The name of the built-in geograph to load
            - Examples: 'marnet', 'north_america_rail', 'oak_ridge_maritime', 'us_freeway'

        Optional Arguments:

        - `cache_dir`
            - Type: str | None
            - What: Path to the local cache directory where geograph files are stored
            - Default: None (resolves to the platform-appropriate cache directory)
                - Linux:   ~/.cache/scgraph/
                - macOS:   ~/Library/Caches/scgraph/
                - Windows: %LOCALAPPDATA%\\scgraph\\
        - `geograph_url`
            - Type: str
            - What: The base URL where the built-in geograph .graphjson files are hosted
        - `reduce_iterations`
            - Type: int
            - What: Number of reduction iterations to perform upon loading. If 0, no reduction is done. If -1, reduces iteratively until convergence.
            - Default: 0
        - `lazy`
            - Type: bool
            - What: Whether to delay loading/fetching the geograph until its first use
            - Default: False
        """
        if lazy:
            return LazyGeoGraph(
                lambda: GeoGraph.load_geograph(
                    name=name,
                    cache_dir=cache_dir,
                    geograph_url=geograph_url,
                    reduce_iterations=reduce_iterations,
                    lazy=False,
                )
            )
        cache_path = (
            Path(cache_dir)
            if cache_dir is not None
            else get_default_cache_path()
        )
        cache_path.mkdir(parents=True, exist_ok=True)
        cached_file = cache_path.joinpath(f"{name}.graphjson")
        if not cached_file.exists():
            GeoGraph.__fetch_geograph_to_cache__(
                name, cached_file, geograph_url
            )
        return GeoGraph.load_from_graphjson(
            str(cached_file), reduce_iterations=reduce_iterations, lazy=False
        )

    @staticmethod
    def list_geographs(
        cache_dir: str | None = None,
        geograph_url: str = "https://raw.githubusercontent.com/connor-makowski/scgraph/main/geographs",
    ) -> list[dict]:
        """
        Function:

        - List all built-in GeoGraphs available, indicating which are already cached locally.
        - Fetches the available geograph names from a `contents.txt` file at the geograph URL.

        Optional Arguments:

        - `cache_dir`
            - Type: str | None
            - What: Path to the local cache directory to check for cached files
            - Default: None (resolves to the platform-appropriate cache directory)
                - Linux:   ~/.cache/scgraph/
                - macOS:   ~/Library/Caches/scgraph/
                - Windows: %LOCALAPPDATA%\\scgraph\\
        - `geograph_url`
            - Type: str
            - What: The base URL where the geograph files and contents.txt are hosted
            - Default: https://raw.githubusercontent.com/connor-makowski/scgraph/main/geographs

        Returns:

        - A list of dicts, one per available geograph, sorted by name:
            - `name`: str — the geograph name (without extension)
            - `cached`: bool — whether the file is already in the local cache
        """
        url = f"{geograph_url.rstrip('/')}/contents.txt"
        response = requests.get(url)
        if not response.ok:
            raise ConnectionError(
                f"Failed to fetch geograph list from '{url}'. "
                f"HTTP status: {response.status_code}."
            )
        cache_path = (
            Path(cache_dir)
            if cache_dir is not None
            else get_default_cache_path()
        )
        available = sorted(
            line.removesuffix(".graphjson")
            for line in response.text.splitlines()
            if line.strip().endswith(".graphjson")
        )
        return [
            {
                "name": name,
                "cached": cache_path.joinpath(f"{name}.graphjson").exists(),
            }
            for name in available
        ]

    @staticmethod
    def clear_geograph_cache(cache_dir: str | None = None) -> None:
        """
        Function:

        - Remove the local geograph cache directory and all its contents.

        Optional Arguments:

        - `cache_dir`
            - Type: str | None
            - What: Path to the local cache directory to clear
            - Default: None (resolves to the platform-appropriate cache directory)
                - Linux:   ~/.cache/scgraph/
                - macOS:   ~/Library/Caches/scgraph/
                - Windows: %LOCALAPPDATA%\\scgraph\\
        """
        cache_path = (
            Path(cache_dir)
            if cache_dir is not None
            else get_default_cache_path()
        )
        if cache_path.exists():
            shutil.rmtree(cache_path)

    @staticmethod
    def load_from_osmnx_graph(
        osmnx_graph,
        coord_precision: int = 5,
        weight_precision: int = 3,
        weight_key: Literal["length", "travel_time"] = "length",
        off_graph_travel_speed: int | float | None = None,
        load_intermediate_nodes: bool = True,
        silent: bool = False,
        reduce_iterations: int = 0,
        lazy: bool = False,
    ):
        """
        Function:

        - Load a GeoGraph from an OSMnx graph object
        - This function:
            - Will convert the OSMnx graph into a GeoGraph object
            - Rounds the coordinates to the specified precision
            - Rounds the weights to the specified precision (in kilometers)
            - This preserves directionality of edges from the OSMnx graph

        Required Arguments:

        - `osmnx_graph`
            - Type: osmnx.graph
            - What: The OSMnx graph object to load
            - EG: G

        Optional Arguments:

        - `coord_precision`
            - Type: int
            - What: Decimal places to round coordinates when loading the graph
            - Default: 5
        - `weight_precision`
            - Type: int
            - What: Decimal places to round weights when loading the graph
            - Default: 3
            - Note: By default, OSMNX returns meters, but they are adjusted to kilometers in this function before rounding
        - `weight_key`
            - Type: str
            - What: The edge attribute to use as the weight for the graph
            - Options:
                - 'length': Use the length attribute (in kilometers)
                - 'travel_time': Use the travel_time attribute (in seconds)
            - Default: 'length'
        - `off_graph_travel_speed`
            - Type: int | float | None
            - What: The travel speed (km/h) to assume for off-graph travel when using travel_time (seconds) as the weight key
            - Default: None
            - Options:
                - If None and weight_key is 'travel_time'
                    - The default_off_graph_circiuity will be set to 0 (assuming instant travel off graph)
                    - The default_node_addition_circuity will be set to 240
                        - This assumes 15 km/h off graph travel speed when optimizing for entry
                        - This is not included in final returned length, but only used to choose an optimal entry node into the graph
                - If None and weight_key is 'length', the function will ignore this parameter
                - If a number, the function will use this speed to convert off-graph distances to travel times in seconds
        - `load_intermediate_nodes`
            - Type: bool
            - What: Whether to load the intermediate nodes for each edge (if they exist)
            - Default: True
        - `silent`
            - Type: bool
            - What: Whether to suppress progress output to the console when loading the graph
            - Default: False
        - `reduce_iterations`
            - Type: int
            - What: Number of reduction iterations to perform upon loading. If 0, no reduction is done. If -1, reduces iteratively until convergence.
            - Default: 0
        - `lazy`
            - Type: bool
            - What: Whether to delay loading the geograph until its first use
            - Default: False

        """
        if lazy:
            return LazyGeoGraph(
                lambda: GeoGraph.load_from_osmnx_graph(
                    osmnx_graph=osmnx_graph,
                    coord_precision=coord_precision,
                    weight_precision=weight_precision,
                    weight_key=weight_key,
                    off_graph_travel_speed=off_graph_travel_speed,
                    load_intermediate_nodes=load_intermediate_nodes,
                    silent=silent,
                    reduce_iterations=reduce_iterations,
                    lazy=False,
                )
            )
        node_list = list(osmnx_graph.nodes)
        node_to_idx = {node: i for i, node in enumerate(node_list)}

        graph = [dict() for _ in range(len(node_list))]
        if load_intermediate_nodes:
            intermediate_nodes = [dict() for _ in range(len(node_list))]
        weight_divisor = 1000 if weight_key == "length" else 1
        for u, v, data in osmnx_graph.edges(data=True):
            i = node_to_idx[u]
            j = node_to_idx[v]
            weight = round(
                float(data.get(weight_key)) / weight_divisor, weight_precision
            )
            graph[i][j] = min(graph[i].get(j, float("inf")), weight)
            if load_intermediate_nodes and "geometry" in data:
                intermediate_nodes[i][j] = [
                    [
                        round(coord[1], coord_precision),
                        round(coord[0], coord_precision),
                    ]
                    for coord in data["geometry"].coords
                ]

        nodes = [None] * len(node_list)
        for node, data in osmnx_graph.nodes(data=True):
            nodes[node_to_idx[node]] = [
                round(data["y"], coord_precision),
                round(data["x"], coord_precision),
            ]
        kwargs = {}
        if load_intermediate_nodes:
            kwargs["intermediate_nodes"] = intermediate_nodes
        # Handle travel_time specific parameters
        if weight_key == "travel_time":
            if off_graph_travel_speed is None:
                print_console(
                    "No off_graph_travel_speed provided but weight_key = 'travel_time'. Assuming instant travel off graph. Setting default_off_graph_circuity to 0 and default_node_addition_circuity to 240.",
                    silent=silent,
                )
                kwargs["default_off_graph_circuity"] = 0
                kwargs["default_node_addition_circuity"] = 240
            else:
                off_graph_speed_km_per_s = off_graph_travel_speed / 3600
                kwargs["default_off_graph_circuity"] = (
                    1 / off_graph_speed_km_per_s
                )
                kwargs["default_node_addition_circuity"] = (
                    1 / off_graph_speed_km_per_s
                )

        # TODO: Handle time based geograph units in a better way by default.
        # See: self.geograph_units
        geograph = GeoGraph(graph=graph, nodes=nodes, **kwargs)
        geograph.graph_object.reduce(reduce_iterations)
        return geograph

    # Misc IO Methods
    @staticmethod
    def get_multi_path_geojson(
        routes: list[dict],
        filename: str | None = None,
        show_progress: bool = False,
        get_intermediate_nodes: bool = True,
    ) -> dict:
        """
        Creates a GeoJSON file with the shortest path between the origin and destination of each route.

        Required Parameters:

        - `routes`: list[dict]
            - List of dictionaries with the following keys:
                - geograph: GeoGraph
                    - Geograph object to use for the shortest path calculation.
                - origin: dict[float|float]
                    - Origin coordinates
                    - EG: {"latitude":39.2904, "longitude":-76.6122}
                - destination: dict[float|int]
                    - Destination coordinates
                    - EG: {"latitude":39.2904, "longitude":-76.6122}
                - properties: dict
                    - Dictionary with the properties of the route
                    - Everything in this dictionary will be included in the output GeoJSON file as properties of the route.
                    - EG: {"id":"route_1", "name":"Route 1", "color":"#ff0000"}

        Optional Parameters:

        - `filename`: str | None
            - Name of the output GeoJSON file.
            - If None, the function will not save the file
            - Default: None
        - `show_progress`: bool
            - Whether to show basic progress information
            - Default: False
        - `silent`: bool
            - Whether to suppress console output
            - Default: False
        - `get_intermediate_nodes`: bool
            - Whether to include intermediate nodes in the shortest path calculation
            - Default: False

        Returns

        - `output`: dict
            - Dictionary with the GeoJSON file content.
        """
        assert isinstance(routes, list), "Routes must be a list"
        assert all(
            [isinstance(i, dict) for i in routes]
        ), "Routes must be a list of dictionaries"
        assert all(
            [isinstance(i.get("geograph"), GeoGraph) for i in routes]
        ), "All routes must have a 'geograph' key with a GeoGraph object"
        assert all(
            [isinstance(i.get("origin"), dict) for i in routes]
        ), "All routes must have an 'origin' key with a dictionary"
        assert all(
            [isinstance(i.get("destination"), dict) for i in routes]
        ), "All routes must have a 'destination' key with a dictionary"
        assert all(
            [isinstance(i.get("properties"), dict) for i in routes]
        ), "All routes must have a 'properties' key with a dictionary"
        assert all(
            [
                isinstance(i["origin"].get("latitude"), (int, float))
                for i in routes
            ]
        ), "All origins must have a 'latitude' key with a number"
        assert all(
            [
                isinstance(i["origin"].get("longitude"), (int, float))
                for i in routes
            ]
        ), "All origins must have a 'longitude' key with a number"
        assert all(
            [
                isinstance(i["destination"].get("latitude"), (int, float))
                for i in routes
            ]
        ), "All destinations must have a 'latitude' key with a number"
        assert all(
            [
                isinstance(i["destination"].get("longitude"), (int, float))
                for i in routes
            ]
        ), "All destinations must have a 'longitude' key with a number"
        assert all(
            [
                (
                    i["origin"].get("latitude") >= -90
                    and i["origin"].get("latitude") <= 90
                )
                for i in routes
            ]
        ), "All origin latitudes must be between -90 and 90"
        assert all(
            [
                (
                    i["origin"].get("longitude") >= -180
                    and i["origin"].get("longitude") <= 180
                )
                for i in routes
            ]
        ), "All origin longitudes must be between -180 and 180"
        assert all(
            [
                (
                    i["destination"].get("latitude") >= -90
                    and i["destination"].get("latitude") <= 90
                )
                for i in routes
            ]
        ), "All destination latitudes must be between -90 and 90"
        assert all(
            [
                (
                    i["destination"].get("longitude") >= -180
                    and i["destination"].get("longitude") <= 180
                )
                for i in routes
            ]
        ), "All destination longitudes must be between -180 and 180"

        output = {"type": "FeatureCollection", "features": []}
        len_routes = len(routes)
        for idx, route in enumerate(routes):
            shortest_path = route["geograph"].get_shortest_path(
                origin_node=route["origin"],
                destination_node=route["destination"],
                get_intermediate_nodes=True,
            )
            shortest_line_path = get_line_path(shortest_path)
            output["features"].append(
                {
                    "type": "Feature",
                    "properties": route["properties"],
                    "geometry": shortest_line_path,
                }
            )
            if show_progress:
                print(
                    f"[{'='*(int((idx+1)/len_routes*20))}>{' '*(20-int((idx+1)/len_routes*20))}] {idx+1}/{len_routes}",
                    end="\r",
                )
        if show_progress:
            print()
        if filename is not None:
            json.dump(output, open(filename, "w"))
        return output


class GeoGraphModifiers:
    def add_edge(
        self,
        origin_id: int,
        destination_id: int,
        distance: int | float,
        symmetric: bool = False,
    ) -> None:
        return self.graph_object.add_edge(
            origin_id=origin_id,
            destination_id=destination_id,
            distance=distance,
            symmetric=symmetric,
        )

    def remove_node(
        self, symmetric_node: bool = False
    ) -> dict[int, int | float]:
        return self.graph_object.remove_node(symmetric_node=symmetric_node)

    def remove_edge(
        self, origin_id: int, destination_id: int, symmetric: bool = False
    ) -> int | float | None:
        return self.graph_object.remove_edge(
            origin_id=origin_id,
            destination_id=destination_id,
            symmetric=symmetric,
        )

    def add_coord_edge(
        self,
        origin_coord_dict: dict[str, float | int],
        destination_coord_dict: dict[str, float | int],
        symmetric: bool = True,
        distance: float | int | None = None,
        circuity: float | int = 1,
    ) -> None:
        """
        Function:

        - Add an edge to the graph between two nodes specified by their coordinates
        - Finds the closest nodes in the graph to the provided coordinates and adds an edge between them

        Required Arguments:

        - `origin_coord_dict`
            - Type: dict
            - What: A dictionary with the keys 'latitude' and 'longitude' for the origin node
            - Note: The function will find the closest node in the graph to these coordinates and use that as the origin node for the edge
        - `destination_coord_dict`
            - Type: dict
            - What: A dictionary with the keys 'latitude' and 'longitude' for the destination node
            - Note: The function will find the closest node in the graph to these coordinates and use that as the destination node for the edge

        Optional Arguments:

        - `symmetric`
            - Type: bool
            - What: Whether to add the edge in both directions
            - Default: True
        - `distance`
            - Type: int | float | None
            - What: The distance to use for the edge. If None, the haversine distance between the origin and destination nodes (the closest nodes to the provided ones) will be used (with circuity applied)
            - Default: None
        - `circuity`
            - Type: int | float
            - What: The circuity to apply to the distance calculation if distance is None
            - Default: 1
        """
        assert isinstance(
            origin_coord_dict, dict
        ), "Origin node must be a dictionary"
        assert isinstance(
            destination_coord_dict, dict
        ), "Destination node must be a dictionary"
        assert (
            "latitude" in origin_coord_dict.keys()
        ), "Origin node must have a latitude"
        assert (
            "longitude" in origin_coord_dict.keys()
        ), "Origin node must have a longitude"
        assert (
            "latitude" in destination_coord_dict.keys()
        ), "Destination node must have a latitude"
        assert (
            "longitude" in destination_coord_dict.keys()
        ), "Destination node must have a longitude"
        assert (
            origin_coord_dict["latitude"] >= -90
            and origin_coord_dict["latitude"] <= 90
        ), "Origin latitude must be between -90 and 90"
        assert (
            origin_coord_dict["longitude"] >= -180
            and origin_coord_dict["longitude"] <= 180
        ), "Origin longitude must be between -180 and 180"
        assert (
            destination_coord_dict["latitude"] >= -90
            and destination_coord_dict["latitude"] <= 90
        ), "Destination latitude must be between -90 and 90"
        assert (
            destination_coord_dict["longitude"] >= -180
            and destination_coord_dict["longitude"] <= 180
        ), "Destination longitude must be between -180 and 180"
        origin_node = [
            origin_coord_dict["latitude"],
            origin_coord_dict["longitude"],
        ]
        destination_node = [
            destination_coord_dict["latitude"],
            destination_coord_dict["longitude"],
        ]
        closest_origin_idx = self.geokdtree.closest_idx(point=origin_node)
        closest_destination_idx = self.geokdtree.closest_idx(
            point=destination_node
        )
        if distance is None:
            distance = (
                haversine(
                    self.nodes[closest_origin_idx],
                    self.nodes[closest_destination_idx],
                )
                * circuity
            )
        self.add_edge(
            origin_id=closest_origin_idx,
            destination_id=closest_destination_idx,
            distance=distance,
            symmetric=symmetric,
        )

    def add_coord_node(
        self,
        coord_dict: dict[str, float | int],
        auto_edge: bool = True,
        circuity: float | int = 1,
        node_addition_type: str = "quadrant",
        node_addition_math: str = "euclidean",
        lat_lon_bound: float | int = 5,
        silent: bool = False,
        temp_node: bool = False,
    ) -> int:
        """
        Function:

        - Add a node to the network
        - Returns the id of the new node
        - Automatically updates the distance matrix to include distances to/from the new node (symmetric)

        Required Arguments:

        - `coord_dict`
            - Type: dict
            - What: A dictionary with the keys 'latitude' and 'longitude'

        Optional Arguments:

        - `auto_edge`
            - Type: bool
            - What: Whether to automatically create edges between the new node and existing nodes in the graph
            - Default: True
        - `circuity`
            - Type: int | float
            - What: The circuity to apply to any auto edge distance calculations
            - Default: 1
        - `node_addition_type`
            - Type: str
            - What: The type of edge creation to use
            - Default: 'quadrant'
            - Options:
                - 'quadrant': Add the closest node in each quadrant (ne, nw, se, sw) to the distance matrix for this node
                - 'closest': Add only the closest node to the distance matrix for this node
                - 'all': Add all nodes to the distance matrix for this node
                - 'kdclosest': Add the closest node using a KD-Tree
        - `node_addition_math`
            - Type: str
            - What: The math to use when calculating the distance between nodes when determining the closest node (or closest quadrant node) to add to the graph
            - Default: 'euclidean'
            - Options:
                - 'euclidean': Use the euclidean distance between nodes. This is much faster but is not accurate (especially near the poles)
                - 'haversine': Use the haversine distance between nodes. This is slower but is an accurate representation of the surface distance between two points on the earth
            - Notes:
                - Once the closest node (or closest quadrant node) is determined, the haversine distance (with circuity) is used to calculate the distance between the nodes when adding it to the graph.
        - `lat_lon_bound`
            - Type: int | float
            - What: Forms a bounding box around the node that is to be added to graph. Only selects graph nodes to consider joining that are within this bounding box.
            - Default: 5
        - `silent`
            - Type: bool
            - What: If True, suppresses all output from the function
            - Default: False
        - `temp_node`
            - Type: bool
            - What: If True, the node is considered temporary and will not be used to increase the __original_graph_length__ value
            - Default: False

        Returns:

        - The id of the new node

        """
        # Validate the inputs
        assert isinstance(coord_dict, dict), "Node must be a dictionary"
        assert "latitude" in coord_dict.keys(), "Node must have a latitude"
        assert "longitude" in coord_dict.keys(), "Node must have a longitude"
        assert (
            coord_dict["latitude"] >= -90 and coord_dict["latitude"] <= 90
        ), "Latitude must be between -90 and 90"
        assert (
            coord_dict["longitude"] >= -180 and coord_dict["longitude"] <= 180
        ), "Longitude must be between -180 and 180"
        node = [coord_dict["latitude"], coord_dict["longitude"]]
        if auto_edge:
            assert circuity >= 1, "Circuity must be greater than or equal to 1"
            assert node_addition_type in [
                "quadrant",
                "all",
                "closest",
                "kdclosest",
            ], f"Invalid node addition type provided ({node_addition_type}), valid options are: ['quadrant', 'all', 'closest']"
            assert node_addition_math in [
                "euclidean",
                "haversine",
            ], f"Invalid node addition math provided ({node_addition_math}), valid options are: ['euclidean', 'haversine']"
            assert isinstance(
                lat_lon_bound, (int, float)
            ), "Lat_lon_bound must be a number"
            assert lat_lon_bound > 0, "Lat_lon_bound must be greater than 0"
            # Get the distances to all relevant nodes
            node_dict = self.__get_node_distances__(
                node=node,
                circuity=circuity,
                node_addition_type=node_addition_type,
                node_addition_math=node_addition_math,
                lat_lon_bound=lat_lon_bound,
                silent=silent,
            )
        else:
            node_dict = {}

        if not temp_node:
            self.__original_graph_length__ += 1

        # Create the node
        new_node_id = self.graph_object.add_node(
            node_dict=node_dict, symmetric=True
        )
        self.nodes.append(node)
        return new_node_id

    def remove_coord_node(self) -> None:
        """
        Function:

        - Remove the last coord node that was appended to the graph
        - Assumes that this node has symmetric flows
            - EG: If node A has a distance of 10 to node B, then node B has a distance of 10 to node A
        """
        self.remove_node(symmetric_node=True)
        self.nodes.pop()

    def add_haversine_edge(
        self,
        origin_idx: int,
        destination_idx: int,
        symmetric: bool = True,
    ) -> None:
        """
        Function:

        - Add an arc to the graph

        Required Arguments:

        - `origin_idx`
            - Type: int
            - What: The index of the origin node
        - `destination_idx`
            - Type: int
            - What: The index of the destination node

        Optional Arguments:

        - `symmetric`
            - Type: bool
            - What: Whether to add the edge in both directions
            - Default: True
        """
        assert origin_idx < len(
            self.graph_object.graph
        ), "Origin node does not exist"
        assert destination_idx < len(
            self.graph_object.graph
        ), "Destination node does not exist"
        self.add_edge(
            origin_id=origin_idx,
            destination_id=destination_idx,
            distance=haversine(
                self.nodes[origin_idx], self.nodes[destination_idx]
            ),
            symmetric=symmetric,
        )

    def merge_with_other_geograph(
        self,
        other_geograph,
        connection_nodes: list[list[int | float]],
        circuity_to_current_geograph: float | int = 1.2,
        circuity_to_other_geograph: float | int = 1.2,
        node_addition_type_current_geograph: str = "closest",
        node_addition_type_other_geograph: str = "closest",
        node_addition_math: str = "euclidean",
    ) -> None:
        """
        Function:

        - Merge the current geograph with another geograph
        - This is useful for combining multiple geographs into one
        - This modifies the current geograph in place

        Required Arguments:

        - `other_geograph`
            - Type: GeoGraph
            - What: The other geograph to merge with
        - `connection_nodes`
            - Type: list of tuples
            - What: A list of [latitude, longitude] pairs that represent the nodes to connect between the two geographs
            - The only connections between the two graphs will be those specified in this list

        Optional Arguments:

        - `circuity_to_current_geograph`
            - Type: int | float
            - What: The circuity factor to apply to the distance calculations between the connection nodes and the current geograph
            - Default: 1.2
        - `circuity_to_other_geograph`
            - Type: int | float
            - What: The circuity factor to apply to the distance calculations between the connection nodes and the other geograph
            - Default: 1.2
        - `node_addition_type_current_geograph`
            - Type: str
            - What: The type of node addition to use when adding the connection nodes to the current geograph
            - Default: 'closest'
            - Options:
                - 'closest': Add the closest node to the connection node in the current geograph
                - 'quadrant': Add the closest node in each quadrant (ne, nw, se, sw) to the connection node in the current geograph
        - `node_addition_type_other_geograph`
            - Type: str
            - What: The type of node addition to use when adding the connection nodes to the other geograph
            - Default: 'closest'
            - Options:
                - 'closest': Add the closest node to the connection node in the other geograph
                - 'quadrant': Add the closest node in each quadrant (ne, nw, se, sw) to the connection node in the other geograph
        - `node_addition_math`
            - Type: str
            - What: The math to use when calculating the distance between nodes in determining which nodes to connect into when applying node addition
            - Note: Haversine distance is used to calculate the distance between the added connection nodes and the existing nodes in the geographs once they are chosen
            - Default: 'euclidean'
            - Options:
                - 'euclidean': Use the euclidean distance between nodes. This is much faster but is not accurate (especially near the poles)
                - 'haversine': Use the haversine distance between nodes. This is slower but is an accurate representation of the surface distance between two points
        """
        node_connection_mapper = {}
        original_other_graph_length = len(other_geograph.graph_object.graph)
        for idx, node in enumerate(connection_nodes):
            node_dict = {
                "latitude": node[0],
                "longitude": node[1],
            }
            # Add the connection node to the current geograph
            new_node_id = self.add_coord_node(
                coord_dict=node_dict,
                circuity=circuity_to_current_geograph,
                node_addition_type=node_addition_type_current_geograph,
                node_addition_math=node_addition_math,
            )
            # Add the connection node to the other geograph
            other_node_id = other_geograph.add_coord_node(
                coord_dict=node_dict,
                circuity=circuity_to_other_geograph,
                node_addition_type=node_addition_type_other_geograph,
                node_addition_math=node_addition_math,
            )
            node_connection_mapper[other_node_id] = new_node_id

        # Store the modified other geograph graph that include the connection nodes
        other_graph = deepcopy(other_geograph.graph_object.graph)
        # Add the other graph nodes to the current geograph (removing the connection nodes since they are already added to the current geograph)
        self.nodes += deepcopy(other_geograph.nodes)[
            :original_other_graph_length
        ]

        # Clean up the other geograph to remove any appended nodes
        while (
            len(other_geograph.graph_object.graph) > original_other_graph_length
        ):
            other_geograph.remove_coord_node()

        graph_length = len(self.graph_object.graph)

        # Create a list based connection map to map the merging nodes into the current graph
        node_connection_map = [
            i + graph_length for i in range(len(other_graph))
        ]
        # Adjust the added nodes to match the nodes added to the current graph
        for idx, node in node_connection_mapper.items():
            node_connection_map[idx] = node
        # Re establish the graph object (To support C++ Graph Objects)
        graph = self.graph_object.graph
        # Fill the current graph with empty dictionaries to match the length of the other graph
        graph.extend(
            [{} for _ in range(len(other_graph) - len(connection_nodes))]
        )
        # Populate the new connections
        for origin_idx, destinations in enumerate(other_graph):
            for destination_idx, distance in destinations.items():
                graph[node_connection_map[origin_idx]][
                    node_connection_map[destination_idx]
                ] = distance
        self.graph_object = Graph(graph=graph)


class GeoGraphUtils:
    def __get_node_distances__(
        self,
        node: list,
        circuity: float | int,
        node_addition_type: str,
        node_addition_math: str,
        lat_lon_bound: float | int,
        silent: bool = False,
    ) -> dict[int, float]:
        """
        Function:

        - Get the distances between a node other connected nodes in the graph
        - This is used to determine the closest node to add to the graph when adding a new node

        Required Arguments:

        - `node`
            - Type: list
            - What: A list of the latitude and longitude of the node
            - EG: [latitude, longitude] -> [31.23, 121.47]
        - `circuity`
            - Type: int | float
            - What: The circuity to apply to any distance calculations
            - Note: This defaults to 4 to prevent the algorithm from taking a direct route in direction of the destination over some impassible terrain (EG: a maritime network that goes through land)
        - `node_addition_type`
            - Type: str
            - What: The type of node addition to use
            - Options:
                - 'kdclosest': Add the closest node using a KD-Tree
                - 'quadrant': Add the closest node in each quadrant (ne, nw, se, sw) to the distance matrix for this node
                - 'closest': Add only the closest node to the distance matrix for this node
                - 'all': Add all nodes to the distance matrix for this node
            - Notes:
                - If you are using 'kdclosest', the lat_lon_bound is ignored as the KD-Tree is globally built
        - `node_addition_math`
            - Type: str
            - What: The math to use when calculating the distance between nodes when determining the closest node (or closest quadrant node) to add to the graph
            - Default: 'euclidean'
            - Options:
                - 'euclidean': Use the euclidean distance between nodes. This is much faster but is not accurate (especially near the poles)
                - 'haversine': Use the haversine distance between nodes. This is slower but is an accurate representation of the surface distance between two points on the earth
            - Notes:
                - Once the closest node (or closest quadrant node) is determined, the haversine distance (with circuity) is used to calculate the distance between the nodes when adding it to the graph.
        - `lat_lon_bound`
            - Type: int | float
            - What: Forms a bounding box around the node that is to be added to graph. Only selects graph nodes to consider joining that are within this bounding box.

        Optional Arguments:

        - `silent`
            - Type: bool
            - What: Whether to suppress output messages
            - Default: False
        """
        if node_addition_type == "kdclosest":
            closest_idx = self.geokdtree.closest_idx(point=node)
            closest_point = self.nodes[closest_idx]
            return {
                closest_idx: haversine(node, closest_point, circuity=circuity),
            }
        assert node_addition_type in [
            "quadrant",
            "all",
            "closest",
        ], f"Invalid node addition type provided ({node_addition_type}), valid options are: ['quadrant', 'all', 'closest', 'kdclosest']"
        assert node_addition_math in [
            "euclidean",
            "haversine",
        ], f"Invalid node addition math provided ({node_addition_math}), valid options are: ['euclidean', 'haversine']"
        # Get only bounded nodes
        # Find the only keep nodes that are within the bounding latitude
        top_lat = node[0] + lat_lon_bound
        bottom_lat = node[0] - lat_lon_bound
        top_lon = node[1] + lat_lon_bound
        bottom_lon = node[1] - lat_lon_bound
        nodes = {
            node_idx: node_i
            for node_idx, node_i in enumerate(self.nodes)
            if node_i[0] >= bottom_lat
            and node_i[0] <= top_lat
            and node_i[1] >= bottom_lon
            and node_i[1] <= top_lon
        }
        if len(nodes) == 0:
            print_console(
                f"When adding your origin or destination node to the graph, no nodes found within the bounding box of {lat_lon_bound} degrees around the node {node}.",
                silent=silent,
            )
            print_console(
                "Using KD-Tree to find closest node instead.", silent=silent
            )
            closest_idx = self.geokdtree.closest_idx(point=node)
            closest_point = self.nodes[closest_idx]
            return {
                closest_idx: round(
                    haversine(node, closest_point, circuity=circuity), 4
                )
            }
        if node_addition_type == "all":
            return {
                node_idx: round(haversine(node, node_i, circuity=circuity), 4)
                for node_idx, node_i in nodes.items()
            }
        if node_addition_math == "haversine":
            dist_fn = lambda x: haversine(node, x, circuity=circuity)
        elif node_addition_math == "euclidean":
            # Note this is squared euclidean distance since it is not used except for comparison
            dist_fn = lambda x: (node[0] - x[0]) ** 2 + (node[1] - x[1]) ** 2
        if node_addition_type == "closest":
            quadrant_fn = lambda x, y: "all"
        else:
            quadrant_fn = lambda x, y: ("n" if x[0] - y[0] > 0 else "s") + (
                "e" if x[1] - y[1] > 0 else "w"
            )
        min_diffs = {}
        min_diffs_idx = {}
        for node_idx, node_i in nodes.items():
            quadrant = quadrant_fn(node_i, node)
            dist = dist_fn(node_i)
            if dist < min_diffs.get(quadrant, float("inf")):
                min_diffs[quadrant] = dist
                min_diffs_idx[quadrant] = node_idx
        return {
            node_idx: round(
                haversine(node, self.nodes[node_idx], circuity=circuity), 4
            )
            for node_idx in min_diffs_idx.values()
        }

    def __get_intermediate_nodes__(
        self, origin_idx: int, destination_idx: int, sequence: str = "lat_lon"
    ) -> list[list[float | int]]:
        """
        Function:

        - Get the intermediate nodes between two nodes if they exist in the graph object
        - Note: Not as performant so not used in __get_coordinate_path__, but can be used in post processing of the path if desired

        Required Arguments:

        - `origin_idx`
            - Type: int
            - What: The index of the origin node
        - `destination_idx`
            - Type: int
            - What: The index of the destination node
        - `sequence`
            - Type: str
            - What: The sequence of coordinates to return, either "lat_lon" or "lon_lat"
            - Default: "lat_lon"
        """
        if self.intermediate_nodes is not None:
            assert sequence in [
                "lat_lon",
                "lon_lat",
            ], f"Invalid sequence provided ({sequence}), valid options are: ['lat_lon', 'lon_lat']"
            out = self.intermediate_nodes[origin_idx].get(destination_idx, [])
            if sequence == "lon_lat":
                out = [[coord[1], coord[0]] for coord in out]
            return out
        else:
            return []

    def __format_coordinates__(
        self,
        coordinate_path: list[list[float | int]],
        output_format: str = "list_of_lists",
    ) -> list:
        """
        Function:

        Arguments:

        - `coordinate_path`
            - Type: list of lists
            - What: A list of lists where each sublist is a coordinate [latitude, longitude]
        - `output_format`
            - Type: str
            - What: The format to return the coordinates in
            - Options:
                - 'list_of_lists': A list of lists with the first value being latitude and the second being longitude
                - 'list_of_lists_long_first': A list of lists with the first value being longitude and the second being latitude
                - 'list_of_dicts': A list of dictionaries with keys 'latitude' and 'longitude'
            - Default: 'list_of_lists'

        """
        if output_format == "list_of_lists":
            return coordinate_path
        elif output_format == "list_of_lists_long_first":
            return [[i[1], i[0]] for i in coordinate_path]
        elif output_format == "list_of_dicts":
            return [
                {"latitude": i[0], "longitude": i[1]} for i in coordinate_path
            ]
        else:
            raise ValueError(
                "Invalid output_format. Must be one of 'list_of_lists', 'list_of_lists_long_first', or 'list_of_dicts'"
            )

    def __cleanup_temp_nodes__(self):
        """
        Function:

        - Remove any temporary nodes that were added to the graph during shortest path calculations
        """
        while len(self.graph_object.graph) > self.__original_graph_length__:
            self.remove_coord_node()

    def __get_coordinate_path__(
        self, path: list[int], get_intermediate_nodes: bool = False
    ) -> list[list[float | int]]:
        """
        Function:

        - Return a list of node dictionaries (lat + long) in the order they are visited

        Required Arguments:

        - `path`
            - Type: list
            - What: A list of node ids in the order they are visited

        Optional Arguments:

        - `get_intermediate_nodes`
            - Type: bool
            - What: If True, returns the intermediate nodes in the path (if they exist for each segment)
            - Default: False
        """
        if get_intermediate_nodes and self.intermediate_nodes is not None:
            # Start with the origin node
            coordinate_path = [self.nodes[path[0]]]
            # Note: The first and last node in the path are off graph so they do not have intermediate nodes.
            for i in range(1, len(path) - 1):
                origin_id = path[i]
                destination_id = path[i + 1]
                intermediate_nodes = self.intermediate_nodes[origin_id].get(
                    destination_id, []
                )
                coordinate_path.extend(intermediate_nodes)
                # Add the destination node
                coordinate_path.append(self.nodes[destination_id])
            return coordinate_path
        return [self.nodes[node_id] for node_id in path]

    def get_path_weight(
        self,
        path_result: dict,
        off_graph_circuity: float | int = None,
        output_units: str = "km",
    ) -> float:
        """
        Function:

        - Compute the total weight of a pre-computed path in this geograph's units

        - This allows computing the weight of a path optimized for one metric
          (e.g., time) using a different geograph's weights (e.g., distance),
          including the off-graph entry and exit segments using this geograph's
          circuity.

        Required Arguments:

        - `path_result`
            - Type: dict
            - What: The output from `get_shortest_path` called with `output_path=True`
            - Must contain both a `path` key (list of on-graph node ids) and a
              `coordinate_path` key (list of [lat, lon] pairs)

        Optional Arguments:

        - `off_graph_circuity`
            - Type: float | int | None
            - What: Circuity to apply to the off-graph entry and exit haversine
              distances. Defaults to `self.default_off_graph_circuity`.
            - Default: None

        - `output_units`
            - Type: str
            - What: Units for the returned weight value
            - Default: 'km'

        Returns:

        - The total weight of the path in this geograph's edge units, converted
          to `output_units`
        """
        if off_graph_circuity is None:
            off_graph_circuity = self.default_off_graph_circuity
        path = path_result.get("path")
        coordinate_path = path_result.get("coordinate_path")
        assert (
            path is not None
        ), "path_result must contain a 'path' key; call get_shortest_path with output_path=True"
        assert (
            coordinate_path is not None
        ), "path_result must contain a 'coordinate_path' key"

        origin = coordinate_path[0]
        destination = coordinate_path[-1]

        if len(path) == 0:
            # Edge case: origin and destination map to the same graph node
            total = haversine(
                origin,
                destination,
                circuity=off_graph_circuity,
                units=self.geograph_units,
            )
        else:
            on_graph_weight = self.graph_object.get_path_weight(path)
            origin_off = haversine(
                origin,
                self.nodes[path[0]],
                circuity=off_graph_circuity,
                units=self.geograph_units,
            )
            destination_off = haversine(
                self.nodes[path[-1]],
                destination,
                circuity=off_graph_circuity,
                units=self.geograph_units,
            )
            total = on_graph_weight + origin_off + destination_off

        return distance_converter(
            total,
            input_units=self.geograph_units,
            output_units=output_units,
        )

    def validate(
        self,
        check_symmetry: bool = True,
        check_connected: bool = True,
    ) -> None:
        return self.graph_object.validate(
            check_symmetry=check_symmetry,
            check_connected=check_connected,
        )


class GeoGraphDistanceCalculations:
    def haversine(
        self,
        origin_id: int,
        destination_id: int,
    ):
        """
        Function:

        - Calculate the haversine distance between two points on the Earth.

        Required Arguments:

        - `origin_id`
            - Type: int
            - What: The id of the origin node in the graph
        - `destination_id`
            - Type: int
            - What: The id of the destination node in the graph

        Optional Arguments:

        - None
        """
        return haversine(
            origin=self.nodes[origin_id],
            destination=self.nodes[destination_id],
            units="km",
            circuity=1,
        )

    def cheap_ruler(
        self,
        origin_id: int,
        destination_id: int,
    ):
        """
        Function:

        - Calculate the distance between two points on the Earth using the cheap ruler algorithm.
        - This is based off of Mapbox's cheap ruler algorithm which is a fast approximation of the haversine distance
        - It has modifications to support distances across the antimeridian

        Required Arguments:

        - `origin_id`
            - Type: int
            - What: The id of the origin node in the graph
        - `destination_id`
            - Type: int
            - What: The id of the destination node in the graph

        Optional Arguments:

        - None
        """
        return cheap_ruler(
            origin=self.nodes[origin_id],
            destination=self.nodes[destination_id],
            units="km",
            # Use a circuity factor of 0.95 to account for the fact that cheap_ruler can overestimate distances
            circuity=0.9,
        )


class GeoGraph(
    GeoGraphIO, GeoGraphModifiers, GeoGraphUtils, GeoGraphDistanceCalculations
):
    def __init__(
        self,
        graph: list[dict[int, int | float]],
        nodes: list[list[float | int]],
        validate: bool = False,
        intermediate_nodes: list[list[list[float | int]]] = None,
        default_off_graph_circuity: float | int = 1,
        default_node_addition_circuity: float | int = 4,
        geograph_units: Literal["km", "m", "mi", "ft"] = "km",
    ) -> None:
        """
        Function:

        - Create a GeoGraph object

        Required Arguments:

        - `graph`
            - Type: list of dictionaries
            - See: https://connor-makowski.github.io/scgraph/scgraph/graph.html#Graph
        - `nodes`
            - Type: list of lists of ints or floats
            - What: A list of lists where the values are coordinates (latitude then longitude)
            - Note: The length of the nodes list must be the same as that of the graph list
            - Example:
            ```
                [
                    # London (index 0)
                    [51.5074, 0.1278],
                    # Paris (index 1)
                    [48.8566, 2.3522],
                    # Berlin (index 2)
                    [52.5200, 13.4050],
                    # Rome (index 3)
                    [41.9028, 12.4964],
                    # Madrid (index 4)
                    [40.4168, 3.7038],
                    # Lisbon (index 5)
                    [38.7223, 9.1393]
                ]
            ```

        Optional Arguments:

        - `validate`
            - Type: bool
            - What: Whether to validate the graph upon initialization
            - Default: False
        - `intermediate_nodes`
            - Type: list of lists of lists of floats or ints
            - What: A list of lists where each sublist contains the intermediate coordinates (latitude then longitude) for each arc in the graph
            - Note: Allows for more detailed path plotting along arcs without needing to increase the number of nodes in the graph
            - Default: None
        - `default_off_graph_circuity`
            - Type: float | int
            - What: The default circuity factor to apply to any distance calculations between your origin and destination nodes and their connecting nodes in the graph
            - Note: This can be used to account for graphs in different units than kilometers (like time).
                - EG: For time, you may opt to just make this 0 so that the off graph distance is not counted towards the total path length (time)
                - EG: For travel_time in seconds, you could assume that the off graph travel speed is 30 km/h, so the off graph circuity should be 3600 / 30 = 120
            - See: `off_graph_circuity` notes in `get_shortest_path` for more information on how to set this value appropriately for your use case
            - Default: 1
        - `default_node_addition_circuity`
            - Type: float | int
            - What: The default circuity factor to apply when adding your origin and destination nodes to the distance matrix
            - See: `default_off_graph_circuity` notes above for more information on how to set this value appropriately for your use case
            - See: `node_addition_circuity` notes in `get_shortest_path` for more information on how to set this value appropriately for your use case
            - Default: 4
        - `geograph_units`
            - Type: str
            - What: The units in which the geograph is represented
            - Default: 'km'
            - Options:
                - 'km': Kilometers
                - 'm': Meters
                - 'mi': Miles
                - 'ft': Feet
        """
        if hasattr(graph, "get_shortest_path") and not isinstance(graph, list):
            self.graph_object = graph
            self.graph = graph.graph
        else:
            self.graph_object = Graph(graph=graph, validate=validate)
            self.graph = graph
        self.nodes = nodes
        self.intermediate_nodes = intermediate_nodes
        self.default_off_graph_circuity = default_off_graph_circuity
        self.default_node_addition_circuity = default_node_addition_circuity
        self.default_get_intermediate_nodes = (
            True if intermediate_nodes is not None else False
        )
        self.geograph_units = geograph_units
        self.geokdtree = GeoKDTree(points=self.nodes)
        self.__original_graph_length__ = len(self.graph_object.graph)

    def reduce(self, iterations: int = 1) -> None:
        """
        Function:

        - Reduce the graph by bypassing pass-through nodes and summing intermediate weights.
        - Precomputes and sets reduced graph structures on self.graph_object for faster queries.

        Optional Arguments:

        - `iterations`:
            - Type: int
            - What: Number of reduction iterations to perform. If -1, reduces iteratively until convergence. If 0, no reduction is done.
            - Default: 1

        Returns:

        - None
        """
        if iterations != 0:
            self.graph_object.reduce(iterations)

    def validate_nodes(self) -> None:
        """

        Function:

        - Validate that self.nodes is properly formatted (see GeoGraph.__init__ docs for more details)
        - Raises an exception if the nodes are invalid
        - Returns None if the nodes are valid

        Required Arguments:

        - None

        Optional Arguments:

        - None
        """
        assert isinstance(self.nodes, list), "Your nodes must be a dictionary"
        assert all(
            [isinstance(i, list) for i in self.nodes]
        ), "Your nodes must be a list of lists"
        assert all(
            [len(i) == 2 for i in self.nodes]
        ), "Your nodes must be a list of lists where each sub list has a length of 2"
        assert all(
            [
                (
                    isinstance(i[0], (int, float))
                    and isinstance(i[1], (int, float))
                )
                for i in self.nodes
            ]
        ), "Your nodes must be a list of lists where each sub list has a numeric latitude and longitude value"
        assert all(
            [
                (i[0] >= -90 and i[0] <= 90 and i[1] >= -180 and i[1] <= 180)
                for i in self.nodes
            ]
        ), "Your nodes must be a list of lists where each sub list has a length of 2 with a latitude [-90,90] and longitude [-180,180] value"

    def get_shortest_path(
        self,
        origin_node: dict[str, float | int],
        destination_node: dict[str, float | int],
        output_units: str = "km",
        algorithm_fn: str = "bidirectional_dijkstra",
        algorithm_kwargs: dict = None,
        off_graph_circuity: float | int = 1,
        node_addition_type: str = "kdclosest",
        node_addition_circuity: float | int = 4,
        output_coordinate_path: str = "list_of_lists",
        output_path: bool = False,
        node_addition_lat_lon_bound: float | int | Literal["auto"] = "auto",
        node_addition_math: str = "euclidean",
        destination_node_addition_type: str = "kdclosest",
        auto_lat_lon_bound_max: float | int = 2,
        silent: bool = False,
        length_only: bool = False,
        get_intermediate_nodes: bool = None,
        **kwargs,
    ) -> dict:
        """
        Function:

        - Identify the shortest path between two nodes in a sparse network graph

        - Return a dictionary of various path information including:
            - `id_path`: A list of node ids in the order they are visited
            - `path`: A list of nodes  (list of lat then long) in the order they are visited
            - `length`: The length of the path

         Required Arguments:

        - `origin_node`
            - Type: dict of int | float
            - What: A dictionary with the keys 'latitude' and 'longitude'
        - `destination_node`
            - Type: dict of int | float
            - What: A dictionary with the keys 'latitude' and 'longitude'

        Optional Arguments:

        - `output_units`
            - Type: str
            - What: The units in which to return the length of the path
            - Default: 'km'
            - Options:
                - 'km': Kilometers
                - 'm': Meters
                - 'mi': Miles
                - 'ft': Feet
        - `algorithm_fn`
            - Type: str | callable
            - What: The algorithm to use for shortest path calculation. Can be a string name of a method on the underlying Graph object, or any callable.
            - Default: 'bidirectional_dijkstra'
            - Options:
                - 'dijkstra' -> GraphAlgorithms.dijkstra
                    - Standard Dijkstra's algorithm; general purpose for non-negative edge weights
                - 'bidirectional_dijkstra' -> GraphAlgorithms.bidirectional_dijkstra
                    - Bidirectional Dijkstra's algorithm; searches from both origin and destination simultaneously, typically faster than standard Dijkstra for point-to-point queries
                - 'dijkstra_negative' -> GraphAlgorithms.dijkstra_negative
                    - Modified Dijkstra supporting negative edge weights; detects negative cycles
                - 'a_star' -> GraphAlgorithms.a_star
                    - A* algorithm; requires a heuristic_fn passed via algorithm_kwargs for speedup
                - 'bellman_ford' -> GraphAlgorithms.bellman_ford
                    - Bellman-Ford algorithm; supports negative weights but slower than dijkstra
                - 'bmssp' -> GraphAlgorithms.bmssp
                    - BMSSP algorithm; not actually faster in practice than dijkstra but included for completeness
                - 'cached_shortest_path' -> GraphAlgorithms.cached_shortest_path
                    - Computes and caches the full shortest path tree from the origin on the first call;
                      subsequent calls from the same origin node are near-instant
                    - Only the origin graph node is cached (not the off-graph origin coordinate)
                    - Note: Requires that both node_addition_type and destination_node_addition_type are 'kdclosest'
                - 'contraction_hierarchy' -> GraphAlgorithms.contraction_hierarchy
                    - Bidirectional Dijkstra on a preprocessed Contraction Hierarchy graph
                    - Requires one-time preprocessing via graph_object.create_contraction_hierarchy()
                      (called automatically on first use if not already done)
                    - Very fast for arbitrary origin-destination queries on large graphs
                    - Note: Requires that both node_addition_type and destination_node_addition_type are 'kdclosest'
                - 'tnr' -> TNRGraph.search
                    - Transit Node Routing; extremely fast for global queries on large graphs
                    - Requires preprocessing via TNRGraph initialization or create_tnr_hierarchy()
                    - Note: Requires that both node_addition_type and destination_node_addition_type are 'kdclosest'
                - Any callable that accepts:
                    - `graph`: The graph (list[dict[int, int | float]]) to perform the shortest path on
                    - `origin_id`: The id of the origin node
                    - `destination_id`: The id of the destination node
                    - `**algorithm_kwargs`: Additional keyword arguments
        - `algorithm_kwargs`
            - Type: dict
            - What: Additional keyword arguments to pass to the algorithm function assuming it accepts them
        - `off_graph_circuity`
            - Type: int | float
            - What: The circuity factor to apply to any distance calculations between your origin and destination nodes and their connecting nodes in the graph
            - Default: 1 (more specifically self.default_off_graph_circuity)
            - Notes:
                - For alogrithmic solving purposes, the node_addition_circuity is applied to the origin and destination nodes when they are added to the graph
                - This is only applied after an `optimal solution` using the `node_addition_circuity` has been found when it is then adjusted to equal the `off_graph_circuity`
                - The off graph KM multiplied by this value is added to the total path length to account for the distance traveled off the graph
        - `node_addition_type`
            - Type: str
            - What: The type of node addition to use when adding your origin node to the distance matrix
            - Default: 'kdclosest' (was 'quadrant' prior to v2.10.0)
            - Options:
                - 'kdclosest': Add the closest node using a KD-Tree
                - 'quadrant': Add the closest node in each quadrant (ne, nw, se, sw) to the distance matrix for this node
                - 'closest': Add only the closest node to the distance matrix for this node
                - 'all': Add all nodes within the bounding box to the distance matrix for this node
        - `node_addition_circuity`
            - Type: int | float
            - What: The circuity factor to apply when adding your origin and destination nodes to the distance matrix
            - Default: 4 (more specifically self.default_node_addition_circuity)
            - Note:
                - This defaults to 4 to prevent the algorithm from taking a direct route in direction of the destination over some impassible terrain (EG: a maritime network that goes through land)
                - A higher value will push the algorithm to join the network at a closer node to avoid the extra distance from the circuity factor
                - This is only relevant if `node_addition_type` is set to 'quadrant' or 'all' as it affects the choice on where to enter the graph network
                - This factor is used to calculate the node sequence for the `optimal route`, however the reported `length` of the path will be calculated using the `off_graph_circuity` factor
        - `output_coordinate_path`
            - Type: str
            - What: The format of the output coordinate path
            - Default: 'list_of_lists'
            - Options:
                - 'list_of_dicts': A list of dictionaries with keys 'latitude' and 'longitude'
                - 'list_of_lists': A list of lists with the first value being latitude and the second being longitude
                - 'list_of_lists_long_first': A list of lists with the first value being longitude and the second being latitude
        - `output_path`
            - Type: bool
            - What: Whether to output the path as a list of geograph node ids (for debugging and other advanced uses)
            - Default: False
        - `node_addition_lat_lon_bound`
            - Type: int | float | Literal["auto"]
            - What: Forms a bounding box around the origin and destination nodes as they are added to graph
                - Only points on the current graph inside of this bounding box are considered when updating the distance matrix for the origin or destination nodes
            - Default: 'auto'
            - If set to 'auto', the bounding box is set based on the distance between the origin and destination nodes capped at `auto_lat_lon_bound_max` for the origin node
            - Note: This is only used when adding a new node (the specified origin and destination) to the graph
        - `auto_lat_lon_bound_max`
            - Type: int | float
            - What: The maximum value for the automatic latitude/longitude bounding box used only for the origin node when `node_addition_lat_lon_bound` is set to 'auto'
            - Default: 2
            - Note: Only used if `node_addition_lat_lon_bound` is set to 'auto'
        - `node_addition_math`
            - Type: str
            - What: The math to use when calculating the distance between nodes when determining the closest node (or closest quadrant node) to add to the graph
            - Default: 'euclidean'
            - Options:
                - 'euclidean': Use the euclidean distance between nodes. This is much faster but is not as accurate (especially near the poles)
                - 'haversine': Use the haversine distance between nodes. This is slower but is an accurate representation of the surface distance between two points on the earth
            - Notes:
                - Only used if `node_addition_type` is set to 'quadrant' or 'closest'
        - `destination_node_addition_type`
            - Type: str
            - What: The method to use when adding the destination node to the graph
            - Default: 'kdclosest' (was 'all' in functionality prior to v2.10.0)
            - Options:
                - 'kdclosest': Add the closest node using a KD-Tree
                - 'closest': Add the node to the closest point in the graph
                - 'quadrant': Add the node to the quadrant it belongs to
                - 'all': Add the node to all points in the graph within the bounding box
        - `silent`
            - Type: bool
            - What: If True, suppresses all output from the function
            - Default: False
        - `length_only`
            - Type: bool
            - What: If True, only returns the length of the path
            - Default: False
        - `get_intermediate_nodes`
            - Type: bool
            - What: If True, returns the intermediate nodes in the path (if they exist for each segment)
            - Default: self.default_get_intermediate_nodes
        - `**kwargs`
            - Additional keyword arguments. These are included for forwards and backwards compatibility reasons, but are not currently used.
        """
        get_intermediate_nodes = (
            get_intermediate_nodes
            if get_intermediate_nodes is not None
            else self.default_get_intermediate_nodes
        )
        off_graph_circuity = (
            off_graph_circuity
            if off_graph_circuity is not None
            else self.default_off_graph_circuity
        )
        node_addition_circuity = (
            node_addition_circuity
            if node_addition_circuity is not None
            else self.default_node_addition_circuity
        )
        algorithm_kwargs = (
            algorithm_kwargs if algorithm_kwargs is not None else dict()
        )
        if callable(algorithm_fn):
            algorithm_kwargs["graph"] = self.graph_object.graph
        elif isinstance(algorithm_fn, str) and hasattr(
            self.graph_object, algorithm_fn
        ):
            algorithm_fn = getattr(self.graph_object, algorithm_fn)
        else:
            raise ValueError("algorithm_fn must be a string or callable")
        if algorithm_fn in [
            self.graph_object.cached_shortest_path,
            self.graph_object.contraction_hierarchy,
            self.graph_object.tnr,
        ]:
            assert (
                node_addition_type == "kdclosest"
            ), "When using the 'cached_shortest_path' or 'contraction_hierarchy' algorithms, node_addition_type must be set to 'kdclosest'"
            assert (
                destination_node_addition_type == "kdclosest"
            ), "When using the 'cached_shortest_path' or 'contraction_hierarchy' algorithms, destination_node_addition_type must be set to 'kdclosest'"
            # Pass length_only to the algorithm kwargs.
            algorithm_kwargs["length_only"] = length_only
        # If auto lat lon bounds are needed, then calculate them.
        if node_addition_lat_lon_bound == "auto":
            if (
                node_addition_type != "kdclosest"
                or destination_node_addition_type != "kdclosest"
            ):
                node_addition_lat_lon_bound_destination = (
                    get_lat_lon_bound_between_pts(origin_node, destination_node)
                    * 1.01
                )
                node_addition_lat_lon_bound_origin = min(
                    node_addition_lat_lon_bound_destination,
                    auto_lat_lon_bound_max,
                )
        try:
            origin = [
                origin_node.get("latitude"),
                origin_node.get("longitude"),
            ]
            destination = [
                destination_node.get("latitude"),
                destination_node.get("longitude"),
            ]
            origin_added = True
            destination_added = True
            origin_entry_length = 0
            destination_exit_length = 0

            # If the node addition type is kdclosest, we can get the closest node and distance without adding a new node to the graph.
            # Otherwise, we need to add a new node to the graph for the origin and destination.
            if node_addition_type == "kdclosest":
                origin_id = self.geokdtree.closest_idx(point=origin)
                origin_entry_length = haversine(
                    origin,
                    self.nodes[origin_id],
                    circuity=off_graph_circuity,
                    units=self.geograph_units,
                )
                origin_added = False
            else:
                origin_id = self.add_coord_node(
                    coord_dict=origin_node,
                    auto_edge=True,
                    node_addition_type=node_addition_type,
                    circuity=node_addition_circuity,
                    lat_lon_bound=node_addition_lat_lon_bound_origin,
                    node_addition_math=node_addition_math,
                    silent=silent,
                    temp_node=True,
                )
            if destination_node_addition_type == "kdclosest":
                destination_id = self.geokdtree.closest_idx(point=destination)
                destination_exit_length = haversine(
                    destination,
                    self.nodes[destination_id],
                    circuity=off_graph_circuity,
                    units=self.geograph_units,
                )
                destination_added = False
            else:
                destination_id = self.add_coord_node(
                    coord_dict=destination_node,
                    auto_edge=True,
                    node_addition_type=destination_node_addition_type,
                    circuity=node_addition_circuity,
                    lat_lon_bound=node_addition_lat_lon_bound_destination,
                    node_addition_math=node_addition_math,
                    silent=silent,
                    temp_node=True,
                )

            # Calculate the shortest path using the specified algorithm function and the origin and destination node ids
            output = algorithm_fn(
                origin_id=origin_id,
                destination_id=destination_id,
                **algorithm_kwargs,
            )
            # Handle circuity adjustments, length conversions, and path adjustments for origin and destination additions
            # Edge case when there is a direct connection between the origin and destination nodes
            if (
                origin_added and destination_added and len(output["path"]) == 2
            ) or len(output.get("path", [])) == 1:
                output["length"] = haversine(
                    origin,
                    destination,
                    circuity=off_graph_circuity,
                    units=self.geograph_units,
                )
                output["path"] = []
            # When not an edge case, apply the normal adjustments
            else:
                # Handle origin additions:
                if origin_added:
                    output["length"] += -self.graph_object.graph[
                        output["path"][0]
                    ][output["path"][1]] + haversine(
                        origin,
                        self.nodes[output["path"][1]],
                        circuity=off_graph_circuity,
                        units=self.geograph_units,
                    )
                    output["path"] = output["path"][1:]
                else:
                    output["length"] += origin_entry_length

                # Handle destination additions
                if destination_added:
                    output["length"] += -self.graph_object.graph[
                        output["path"][-2]
                    ][output["path"][-1]] + haversine(
                        self.nodes[output["path"][-2]],
                        destination,
                        circuity=off_graph_circuity,
                        units=self.geograph_units,
                    )
                    output["path"] = output["path"][:-1]
                else:
                    output["length"] += destination_exit_length

            # Convert the length to the desired output units
            output["length"] = distance_converter(
                output["length"],
                input_units=self.geograph_units,
                output_units=output_units,
            )
            # Early return if only length is needed
            if length_only:
                return {"length": output["length"]}

            # Get the coordinate path
            output["coordinate_path"] = (
                [origin]
                + self.__get_coordinate_path__(
                    output["path"],
                    get_intermediate_nodes=get_intermediate_nodes,
                )
                + [destination]
            )

            # Format the coordinate path to the desired output format
            if output_coordinate_path != "list_of_lists":
                output["coordinate_path"] = self.__format_coordinates__(
                    coordinate_path=output["coordinate_path"],
                    output_format=output_coordinate_path,
                )
                if output_coordinate_path == "list_of_lists_long_first":
                    output["long_first"] = True

            if not output_path:
                del output["path"]
            if origin_added or destination_added:
                self.__cleanup_temp_nodes__()
            return output

        except Exception as e:
            # Cleanup temp nodes from the graph
            self.__cleanup_temp_nodes__()
            print_console(
                (
                    "An error occurred while calculating the shortest path:\n"
                    "This is likely caused by a disconnect in the graph.\n"
                    "You can ensure a solution by setting destination_node_addition_type='all' and setting your lat_lon_bound=180.\n"
                    "This will, however, result in a much longer runtime per shortest path query.\n"
                    "If not in an exception block, see the stacktrace below for more details:\n"
                ),
                silent=silent,
            )
            raise e

    def distance_matrix(
        self,
        nodes: list[dict[str, float | int]],
        off_graph_circuity: float | int = 1,
        output_units: str = "km",
        silent: bool = False,
    ) -> list[list[float | int | None]]:
        """
        Function:

        - Calculate the distance matrix for a list of nodes in a very efficient way using cached shortest path trees and cached node addition distances
        - This should run in O(((n+m)*log(n)*i) + (i*i)) time where i is the number of nodes in the distance matrix, n is the number of nodes in the graph, and m is the number of edges in the graph
           - Compare this to a naive matrix implementation time of O(((n+m)*log(n)*(i*i)) where paths are fetched for each pair of nodes in the distance matrix without caching
        - This is useful for calculating the distance between multiple nodes at the same time

        Required Arguments:

        - `nodes`
            - Type: list[dict[str, float | int]]
            - What: A list of dictionaries with the keys 'latitude' and 'longitude'
            - EG: [{"latitude": 39.2904, "longitude": -76.6122}, {"latitude": 39.2905, "longitude": -76.6123}]

        Optional Arguments:

        - `off_graph_circuity`
            - Type: float | int
            - What: The circuity to apply to the distance calculations for nodes that are not in the graph
            - Default: 1
        - `output_units`
            - Type: str
            - What: The units of the output distance matrix
            - Default: 'km'
            - Options: 'km', 'miles', 'meters', 'feet'

        Returns:

        - A list of lists representing the distance matrix between the nodes
        - The distance matrix is a square matrix where the entry at (i, j) is the distance between node i and node j
        - The distances are in the units specified by `output_units`
        - EG:
        ```
        [
            [0.0, 0.1, ...],
            [0.1, 0.0, ...],
            ...
        ]
        """
        output_matrix = [[None] * len(nodes) for _ in range(len(nodes))]
        dist_multiplier = distance_converter(
            distance=1,
            input_units=self.geograph_units,
            output_units=output_units,
        )
        # Get the entry idx for each node as well as the distance to that node given the off-graph circuity
        # [(entry_idx, distance), ...]
        entry_idx_and_distance = []
        for node in nodes:
            node_idx = self.geokdtree.closest_idx(
                point=[node["latitude"], node["longitude"]]
            )
            distance = haversine(
                [node["latitude"], node["longitude"]],
                self.nodes[node_idx],
                circuity=off_graph_circuity,
                units=output_units,  # Store directly as output units since this is a post processing step
            )
            entry_idx_and_distance.append((node_idx, distance))

        for node_idx_start, (entry_idx_start, entry_length_start) in enumerate(
            entry_idx_and_distance
        ):
            for node_idx_end, (entry_idx_end, entry_length_end) in enumerate(
                entry_idx_and_distance
            ):
                if entry_idx_start == entry_idx_end:
                    output_matrix[node_idx_start][node_idx_end] = 0.0
                    continue
                try:
                    length = self.graph_object.cached_shortest_path(
                        origin_id=entry_idx_start,
                        destination_id=entry_idx_end,
                        length_only=True,
                    )["length"]
                    output_matrix[node_idx_start][node_idx_end] = (
                        (length * dist_multiplier)
                        + entry_length_start
                        + entry_length_end
                    )
                except Exception as e:
                    print_console(
                        f"Error calculating distance between nodes {node_idx_start} and {node_idx_end} with entry indices {entry_idx_start} and {entry_idx_end}.",
                        silent=silent,
                    )

        return output_matrix


class LazyGeoGraph(GeoGraph):
    """
    A lazy-loading proxy for GeoGraph that delays loading/fetching the graph
    until its first attribute access or method invocation.
    """

    def __init__(self, loader_fn) -> None:
        object.__setattr__(self, "_loader_fn", loader_fn)
        object.__setattr__(self, "_initialized", False)

    def _load(self) -> "GeoGraph":
        if not object.__getattribute__(self, "_initialized"):
            loader_fn = object.__getattribute__(self, "_loader_fn")
            real_geo = loader_fn()
            object.__setattr__(self, "_initialized", True)
            object.__getattribute__(self, "__dict__").update(real_geo.__dict__)
        return self

    def load(self) -> "GeoGraph":
        """Explicitly load the underlying GeoGraph if not already loaded."""
        return self._load()

    def __getattribute__(self, name: str):
        if name in (
            "_loader_fn",
            "_initialized",
            "_load",
            "load",
            "__class__",
        ):
            return object.__getattribute__(self, name)
        if not object.__getattribute__(self, "_initialized"):
            object.__getattribute__(self, "_load")()
        return object.__getattribute__(self, name)

    def __setattr__(self, name: str, value) -> None:
        if name in ("_loader_fn", "_initialized"):
            object.__setattr__(self, name, value)
        else:
            if not object.__getattribute__(self, "_initialized"):
                object.__getattribute__(self, "_load")()
            super().__setattr__(name, value)

    def __delattr__(self, name: str) -> None:
        if name in ("_loader_fn", "_initialized"):
            object.__delattr__(self, name)
        else:
            if not object.__getattribute__(self, "_initialized"):
                object.__getattribute__(self, "_load")()
            super().__delattr__(name)

    def __repr__(self) -> str:
        if not object.__getattribute__(self, "_initialized"):
            return f"<LazyGeoGraph (not loaded) at {hex(id(self))}>"
        return f"<LazyGeoGraph (loaded) at {hex(id(self))}>"

    def __dir__(self) -> list[str]:
        self._load()
        return super().__dir__()
